from flask import Flask,render_template
app = Flask(__name__)
@app.route('/hola/<string:name>/')
def hola(name):
    return render_template('test.html',name=name)
app.run()